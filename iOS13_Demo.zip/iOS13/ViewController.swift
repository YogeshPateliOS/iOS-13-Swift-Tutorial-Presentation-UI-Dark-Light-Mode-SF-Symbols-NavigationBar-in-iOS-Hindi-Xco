//
//  ViewController.swift
//  iOS13
//
//  Created by Yogesh Patel on 10/13/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        segment.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : self.view.tintColor ?? .blue], for: .normal)
        segment.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.white], for: .selected)
        segment.selectedSegmentTintColor = view.tintColor
        segment.backgroundColor = .lightText
        
    }
    
    @IBAction func btnSimplePresentationClick(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = false
        let navVC = UINavigationController(rootViewController: pVC)
        self.present(navVC, animated: true, completion: nil)
    }
    
    @IBAction func btnPreventDismiss(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = true
        let navVC = UINavigationController(rootViewController: pVC)
        self.present(navVC, animated: true, completion: nil)
    }
    
    @IBAction func btnFullSheetClick(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = false
        let navVC = UINavigationController(rootViewController: pVC)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true, completion: nil)
    }
    
    @IBAction func btnNavigationClick(_ sender: UIButton) {
        let ncVC = NavigationConfigurationViewController.getNCVC()
        let navVC = UINavigationController(rootViewController: ncVC)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true, completion: nil)
    }
    @IBAction func btnSFSymbolClick(_ sender: UIButton) {
        let sfsVC = SFSymbolViewController.getSFSVC()
        let navVC = UINavigationController(rootViewController: sfsVC)
        self.present(navVC, animated: true, completion: nil)
    }
    
}


