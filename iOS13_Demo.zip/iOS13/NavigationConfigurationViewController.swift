//
//  NavigationConfigurationViewController.swift
//  iOS13
//
//  Created by Yogesh Patel on 10/13/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class NavigationConfigurationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.configureWithOpaqueBackground()
        navBarAppearance.backgroundColor = self.view.tintColor // system  color
        navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.standardAppearance = navBarAppearance
    self.navigationController?.navigationBar.scrollEdgeAppearance = navBarAppearance
    }

    
    @IBAction func btnCancelClick(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
}

extension NavigationConfigurationViewController{
    static func getNCVC() -> NavigationConfigurationViewController{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let ncVC = storyboard.instantiateViewController(identifier: "NavigationConfigurationViewController") as? NavigationConfigurationViewController else{
            fatalError("PresentationVC Not Found in Storyboard")
        }
        return ncVC
    }
}
