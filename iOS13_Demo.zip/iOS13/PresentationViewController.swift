//
//  PresentationViewController.swift
//  iOS13
//
//  Created by Yogesh Patel on 10/13/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class PresentationViewController: UIViewController {
    var modelPresentation = false
    override func viewDidLoad() {
        super.viewDidLoad()
        if modelPresentation{
            self.isModalInPresentation = true
            self.navigationController?.presentationController?.delegate = self
        }
    }
    @IBAction func btnCancelClick(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension PresentationViewController{
    static func getPVC() -> PresentationViewController{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let pVC = storyboard.instantiateViewController(identifier: "PresentationViewController") as? PresentationViewController else{
            fatalError("PresentationVC Not Found in Storyboard")
        }
        return pVC
    }
}

extension PresentationViewController: UIAdaptivePresentationControllerDelegate{
    
    func presentationControllerDidAttemptToDismiss(_ presentationController: UIPresentationController) {
        let alertVC = UIAlertController(title: nil, message: "Are you sure ?", preferredStyle: .actionSheet)
        let dismiss = UIAlertAction(title: "Dismiss", style: .default) { (action) in
            self.dismiss(animated: true , completion: nil)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .default) { (action) in
        }
        alertVC.addAction(dismiss)
        alertVC.addAction(cancel)
        self.present(alertVC, animated: true, completion: nil)
    }
    
}
