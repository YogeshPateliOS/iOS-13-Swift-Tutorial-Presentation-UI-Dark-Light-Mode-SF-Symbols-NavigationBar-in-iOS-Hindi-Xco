//
//  SFSymbolViewController.swift
//  iOS13
//
//  Created by Yogesh Patel on 10/13/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class SFSymbolViewController: UIViewController {

    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var img5: UIImageView!
    @IBOutlet weak var img6: UIImageView!
    let strImgName = "trash.fill"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let arrData = [
            "1":[
                "img" : img1!,
                "type" : UIImage.SymbolWeight.ultraLight
                ],
            "2":[
                "img" : img2!,
                "type" : UIImage.SymbolWeight.thin
                ],
            "3":[
                "img" : img3 ?? UIImageView(),
                "type" : UIImage.SymbolWeight.light
                ],
            "4":[
                "img" : img4 ?? UIImageView(),
                "type" : UIImage.SymbolWeight.medium
                ],
            "5":[
                "img" : img5 ?? UIImageView(),
                "type" : UIImage.SymbolWeight.bold
                ],
            "6":[
                "img" : img6 ?? UIImageView(),
                "type" : UIImage.SymbolWeight.black
                ]
        ]

        for i in 0..<arrData.count{
            if let dict = arrData["\(i+1)"]{
                self.setImageView(imgView: dict["img"] as! UIImageView, type: dict["type"] as! UIImage.SymbolWeight)
            }
        }
//        let configuration = UIImage.SymbolConfiguration(weight: .bold)
//        img1.image =  UIImage(systemName: "trash.fill", withConfiguration: configuration)
    }
    
    func setImageView(imgView: UIImageView, type: UIImage.SymbolWeight){
        let configuration = UIImage.SymbolConfiguration(weight: type)
        imgView.image =  UIImage(systemName: "trash.fill", withConfiguration: configuration)
    }

}

extension SFSymbolViewController{
    static func getSFSVC() -> SFSymbolViewController{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let sfsVC = storyboard.instantiateViewController(identifier: "SFSymbolViewController") as? SFSymbolViewController else{
            fatalError("PresentationVC Not Found in Storyboard")
        }
        return sfsVC
    }
}
